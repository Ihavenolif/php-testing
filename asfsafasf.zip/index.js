function colorFrames()
{
    if(document.forms["form"]["input"].value == 0)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "blue";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "blue";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "blue";

        document.getElementById("c1").style.backgroundColor = "blue";
        document.getElementById("c2").style.backgroundColor = "white";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "blue";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "blue";

        document.getElementById("e1").style.backgroundColor = "blue";
        document.getElementById("e2").style.backgroundColor = "blue";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(     document.forms["form"]["input"].value == 1)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "white";
        document.getElementById("a3").style.backgroundColor = "white";

        document.getElementById("b1").style.backgroundColor = "blue";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "white";

        document.getElementById("c1").style.backgroundColor = "blue";
        document.getElementById("c2").style.backgroundColor = "white";
        document.getElementById("c3").style.backgroundColor = "white";

        document.getElementById("d1").style.backgroundColor = "blue";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "white";

        document.getElementById("e1").style.backgroundColor = "blue";
        document.getElementById("e2").style.backgroundColor = "white";
        document.getElementById("e3").style.backgroundColor = "white";
    }

    if(     document.forms["form"]["input"].value == 2)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "blue";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "white";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "blue";

        document.getElementById("c1").style.backgroundColor = "blue";
        document.getElementById("c2").style.backgroundColor = "blue";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "blue";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "white";

        document.getElementById("e1").style.backgroundColor = "blue";
        document.getElementById("e2").style.backgroundColor = "blue";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(     document.forms["form"]["input"].value == 3)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "blue";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "white";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "blue";

        document.getElementById("c1").style.backgroundColor = "white";
        document.getElementById("c2").style.backgroundColor = "blue";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "white";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "blue";

        document.getElementById("e1").style.backgroundColor = "blue";
        document.getElementById("e2").style.backgroundColor = "blue";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(     document.forms["form"]["input"].value == 4)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "white";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "blue";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "blue";

        document.getElementById("c1").style.backgroundColor = "blue";
        document.getElementById("c2").style.backgroundColor = "blue";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "white";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "blue";

        document.getElementById("e1").style.backgroundColor = "white";
        document.getElementById("e2").style.backgroundColor = "white";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(     document.forms["form"]["input"].value == 5)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "blue";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "blue";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "white";

        document.getElementById("c1").style.backgroundColor = "blue";
        document.getElementById("c2").style.backgroundColor = "blue";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "white";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "blue";

        document.getElementById("e1").style.backgroundColor = "blue";
        document.getElementById("e2").style.backgroundColor = "blue";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(     document.forms["form"]["input"].value == 6)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "blue";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "blue";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "white";

        document.getElementById("c1").style.backgroundColor = "blue";
        document.getElementById("c2").style.backgroundColor = "blue";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "blue";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "blue";

        document.getElementById("e1").style.backgroundColor = "blue";
        document.getElementById("e2").style.backgroundColor = "blue";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(     document.forms["form"]["input"].value == 7)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "blue";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "white";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "blue";

        document.getElementById("c1").style.backgroundColor = "white";
        document.getElementById("c2").style.backgroundColor = "white";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "white";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "blue";

        document.getElementById("e1").style.backgroundColor = "white";
        document.getElementById("e2").style.backgroundColor = "white";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(     document.forms["form"]["input"].value == 8)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "blue";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "blue";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "blue";

        document.getElementById("c1").style.backgroundColor = "blue";
        document.getElementById("c2").style.backgroundColor = "blue";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "blue";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "blue";

        document.getElementById("e1").style.backgroundColor = "blue";
        document.getElementById("e2").style.backgroundColor = "blue";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(     document.forms["form"]["input"].value == 9)
    {
        document.getElementById("a1").style.backgroundColor = "blue";
        document.getElementById("a2").style.backgroundColor = "blue";
        document.getElementById("a3").style.backgroundColor = "blue";
    
        document.getElementById("b1").style.backgroundColor = "blue";
        document.getElementById("b2").style.backgroundColor = "white";
        document.getElementById("b3").style.backgroundColor = "blue";

        document.getElementById("c1").style.backgroundColor = "blue";
        document.getElementById("c2").style.backgroundColor = "blue";
        document.getElementById("c3").style.backgroundColor = "blue";

        document.getElementById("d1").style.backgroundColor = "white";
        document.getElementById("d2").style.backgroundColor = "white";
        document.getElementById("d3").style.backgroundColor = "blue";

        document.getElementById("e1").style.backgroundColor = "white";
        document.getElementById("e2").style.backgroundColor = "white";
        document.getElementById("e3").style.backgroundColor = "blue";
    }

    if(document.forms["form"]["input"].value > 9) alert("Can't display number bigger than 9.");
    if(document.forms["form"]["input"].value < 0) alert("Can't display number smaller than 0.");
    return false;
}