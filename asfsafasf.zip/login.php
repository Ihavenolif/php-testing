<html>
<body>

<?php
    $username = $_REQUEST["username"];
    echo("Your name is " . $username <br>);

    $password = $_REQUEST["password"];
    echo("Your password is " . $password);
?>

</body>
</html>
